#include "small0.hpp"

int factorial(int n) {
	for (int i = n - 1; i > 1; i--)
	{
		n *= i;
	}
	return n;
}
